
from io import BytesIO

from neostrack_api.app import create_app


def test_bonded():
    app = create_app()
    client = app.test_client()
    response = client.get("/device/bonded/123")
    assert response.status_code == 200
    assert response.json["bonded"] is True


def test_dlist():
    app = create_app()
    client = app.test_client()
    response = client.get("/device/dlist/123")
    assert response.status_code == 200


def test_missing_track():
    app = create_app()
    client = app.test_client()
    response = client.post("/device/upload/123", data={})
    assert response.status_code == 400


def test_fit_upload(tmp_path, monkeypatch):
    from neostrack_api import config
    monkeypatch.setattr(config.settings, "data_dir", tmp_path, raising=False)
    # Settings is frozen; this test is illustrative and may be adapted if running locally.
