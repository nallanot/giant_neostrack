# NeoTrack Local Server

> Serveur local compatible avec le Giant NeoTrack, avec réception Wi-Fi
> des fichiers FIT et import facultatif vers FitTrackee.

> [!IMPORTANT]
> Ce projet est **source-available** et non « open source » au sens OSI.
> L'usage commercial, la revente et l'hébergement payant sont interdits
> sans autorisation écrite. Voir [LICENSE](LICENSE).

## Fonctionnalités

- émulation des routes cloud observées du NeoTrack;
- capture des appels vers `upload.neostrack.com` par réécriture DNS;
- réception HTTP/1.0 des fichiers `.fit`;
- sauvegarde atomique et métadonnées JSON;
- import facultatif vers FitTrackee;
- reprises automatiques en cas d'échec;
- suppression locale uniquement après import réussi;
- dossier `failed/` pour éviter toute perte;
- déploiement Docker, Portainer et Traefik;
- PostgreSQL/PostGIS et Redis pour FitTrackee.

## Architecture

```mermaid
flowchart LR
    GPS[Giant NeoTrack] -->|Wi-Fi / DNS| DNS[AdGuard, Pi-hole ou DNS local]
    DNS -->|upload.neostrack.com = IP locale| TR[Traefik :80]
    TR --> API[NeoTrack Flask API]
    API --> IN[/data/incoming]
    IN --> IMP[Import asynchrone]
    IMP --> FT[FitTrackee]
    FT --> DB[(PostgreSQL/PostGIS)]
    FT --> REDIS[(Redis)]
    IMP -->|succès| DEL[Suppression ou archivage]
    IMP -->|échec| FAIL[/data/failed]
```

## Séquence de communication

```mermaid
sequenceDiagram
    participant N as NeoTrack
    participant D as DNS local
    participant T as Traefik
    participant A as API locale
    participant F as FitTrackee

    N->>D: A? upload.neostrack.com
    D-->>N: IP du serveur local
    N->>T: GET /device/bonded/{id} HTTP/1.0
    T->>A: requête HTTP
    A-->>N: 200 OK
    N->>T: GET /device/dlist/{id}
    A-->>N: 200 OK (corps vide)
    N->>T: POST /device/upload/{id}
    T->>A: multipart/form-data, champ track
    A-->>N: 200 OK immédiat
    A->>F: import FIT en arrière-plan
    F-->>A: succès
    A->>A: suppression locale selon configuration
```

## Structure

```text
.
├── neostrack_api/
│   ├── app.py
│   ├── config.py
│   ├── fittrackee.py
│   ├── import_queue.py
│   ├── logging_config.py
│   ├── security.py
│   └── storage.py
├── data/
│   ├── incoming/
│   ├── processed/
│   ├── failed/
│   ├── fittrackee/
│   └── redis/
├── docs/
│   ├── DNS.md
│   ├── PORTAINER.md
│   └── PROTOCOL.md
├── scripts/
│   ├── backup.sh
│   ├── check_dns.sh
│   └── generate_secrets.py
├── tests/
├── .env.example
├── docker-compose.yml
├── Dockerfile
├── LICENSE
├── requirements.txt
└── run.py
```

## Dossiers de données

| Dossier | Fonction |
|---|---|
| `data/incoming` | fichiers FIT reçus et en attente d'import |
| `data/processed` | copies conservées après un import réussi, si activé |
| `data/failed` | fichiers dont l'import a échoué après toutes les tentatives |
| `data/fittrackee/db` | données PostgreSQL/PostGIS |
| `data/fittrackee/uploads` | fichiers gérés par FitTrackee |
| `data/fittrackee/staticmap_cache` | cache cartographique FitTrackee |
| `data/fittrackee/logs` | journaux FitTrackee |
| `data/redis` | données persistantes Redis |

## Installation rapide

### 1. Préparer la configuration

```bash
cp .env.example .env
python3 scripts/generate_secrets.py
```

Copiez les valeurs générées dans `.env`, puis modifiez :

```env
FITTRACKEE_HOST=fittrackee.votre-domaine.tld
UI_URL=https://fittrackee.votre-domaine.tld
TRAEFIK_NETWORK=traefik_default
TRAEFIK_CERT_RESOLVER=ovhresolver
```

Le mot de passe contenu dans `DATABASE_URL` doit être identique à
`POSTGRES_PASSWORD`.

### 2. Construire et lancer

```bash
docker compose config
docker compose pull
docker compose build
docker compose up -d
```

### 3. Vérifier

```bash
docker compose ps
docker logs -f neostrack-api
curl http://127.0.0.1:5000/health
```

L'accès direct sur `127.0.0.1:5000` suppose que vous ajoutez
temporairement un port dans Compose. En production, utilisez le domaine
via Traefik.

## DNS local obligatoire

Le compteur tente toujours de joindre le serveur historique. Créez cette
réécriture :

```text
upload.neostrack.com -> 192.168.1.151
```

Remplacez l'adresse par celle de votre serveur.

### Test

```bash
nslookup upload.neostrack.com
```

La réponse doit être l'adresse privée du serveur.

Consultez [docs/DNS.md](docs/DNS.md) pour AdGuard Home, Pi-hole, DHCP et
les captures `tcpdump`.

## Traefik et HTTP

Le NeoTrack observé utilise **HTTP sur le port 80**. Il reçoit mal une
réponse `301 Moved Permanently`. Le routeur doit donc utiliser :

```yaml
- "traefik.http.routers.neostrack.entrypoints=web"
```

N'attachez aucun middleware de redirection HTTPS à ce routeur.

FitTrackee reste exposé séparément en HTTPS sur `websecure`.

## Activer l'import FitTrackee

Créez d'abord votre compte FitTrackee, puis configurez :

```env
FITTRACKEE_IMPORT_ENABLED=true
FITTRACKEE_USERNAME=nallanot
FITTRACKEE_PASSWORD=mot_de_passe
DELETE_AFTER_IMPORT=true
KEEP_PROCESSED_COPY=false
```

Redéployez :

```bash
docker compose up -d --force-recreate neostrack-api
```

### Politique anti-perte

- le NeoTrack reçoit immédiatement `200 OK`;
- l'import est tenté en arrière-plan;
- le fichier n'est supprimé qu'après succès;
- après échec définitif, il est déplacé dans `data/failed`;
- une erreur texte et les métadonnées sont conservées.

## Journaux

```bash
docker logs -f neostrack-api
docker logs -f fittrackee
docker logs -f fittrackee-workers
docker logs -f fittrackee-db
```

Exemple attendu :

```text
BOND device=1606171200002910
DLIST device=1606171200002910
FIT SAVED: /data/incoming/260617074642.fit
Import FitTrackee réussi
Fichier local supprimé après import
```

## Sauvegarde

```bash
./scripts/backup.sh
```

Sauvegardez au minimum PostgreSQL et `data/failed`.

## Sécurité

- ne publiez jamais `.env`;
- utilisez des secrets aléatoires longs;
- le domaine NeoTrack local doit rester accessible uniquement depuis le
  réseau de confiance;
- ne rendez pas le routeur HTTP NeoTrack accessible publiquement si ce
  n'est pas nécessaire;
- sauvegardez la base avant une mise à niveau FitTrackee.

## Dépannage

### Réponse 301

```bash
curl -v http://upload.neostrack.com/device/bonded/1606171200002910
```

Si `Location: https://...` apparaît, une redirection HTTP→HTTPS est
encore active dans Traefik.

### Réponse 502 FitTrackee

Vérifiez :

```bash
docker compose ps
docker logs fittrackee --tail=200
docker inspect fittrackee --format '{{json .NetworkSettings.Networks}}'
```

### Aucun upload

```bash
sudo tcpdump -i eno1 host IP_DU_NEOSTRACK and port 80 -A -s0
```

### Fichier dans `failed`

Lisez :

```bash
cat data/failed/*.error.txt
```

## Compatibilité FitTrackee

Le Compose reprend les éléments essentiels du déploiement Docker officiel
de FitTrackee v1.3.2 : PostGIS, `sh docker-entrypoint.sh`, volumes
d'uploads/cache/logs et healthcheck. Redis et le worker sont activés pour
les tâches asynchrones et les limites d'API.

## Licence

Consultez [LICENSE](LICENSE). La licence autorise l'utilisation, la
modification et le partage non commerciaux. Elle interdit la vente, le
SaaS payant et l'intégration commerciale sans autorisation écrite.

## Avis

NeoTrack, Giant, FitTrackee et Strava sont des marques appartenant à leurs
propriétaires respectifs. Ce projet communautaire n'est pas affilié à
Giant ou Bryton.
