# Protocole NeoTrack observé

Les routes suivantes ont été observées sur un Giant NeoTrack original :

| Ordre | Méthode | Route |
|---:|---|---|
| 1 | GET | `/device/bonded/<device_id>` |
| 2 | GET | `/device/dlist/<device_id>` |
| 3 | POST | `/device/upload/<device_id>` |

L'upload est envoyé en HTTP/1.0 sur le port 80 avec un corps
`multipart/form-data`. Le fichier est présent dans le champ `track` et
possède généralement un nom comme `260617074642.fit`.

## Réponse minimale compatible

- `bonded`: HTTP 200 avec JSON
- `dlist`: HTTP 200 avec corps vide
- `upload`: HTTP 200 après sauvegarde du fichier

Le serveur répond immédiatement à l'appareil. L'import vers FitTrackee
se poursuit en arrière-plan afin d'éviter les retransmissions du GPS.
