# Déploiement avec Portainer

1. Décompresser le projet sur l'hôte Docker.
2. Copier `.env.example` vers `.env`.
3. Modifier les mots de passe, domaines et le réseau Traefik.
4. Dans Portainer, créer une stack depuis le fichier `docker-compose.yml`.
5. Charger les variables depuis `.env` ou les saisir dans l'interface.
6. Déployer la stack.
7. Vérifier les conteneurs :
   - `neostrack-api`
   - `fittrackee`
   - `fittrackee-db`
   - `fittrackee-redis`
   - `fittrackee-workers`

## Première initialisation FitTrackee

L'image officielle lance `sh docker-entrypoint.sh`, qui exécute les
opérations requises par la version utilisée. Ne remplacez pas cette
commande par un appel Gunicorn personnalisé.

Après le démarrage, ouvrez l'URL FitTrackee et créez un compte. Si les
courriels ne sont pas configurés, l'activation peut nécessiter une action
administrative selon les paramètres de l'instance.

## Import automatique

Après la création du compte :

```env
FITTRACKEE_IMPORT_ENABLED=true
FITTRACKEE_USERNAME=votre_identifiant
FITTRACKEE_PASSWORD=votre_mot_de_passe
```

Redéployez ensuite la stack.
