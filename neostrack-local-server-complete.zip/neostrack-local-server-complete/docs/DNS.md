# Capture DNS des appels NeoTrack

## Principe

Le compteur conserve le nom d'hôte historique `upload.neostrack.com`.
Le réseau local doit répondre avec l'adresse IP privée du serveur Docker.

Exemple :

```text
upload.neostrack.com -> 192.168.1.151
```

Le domaine `corp.brytonsport.com` a également été observé. Ne le redirigez
que si une fonctionnalité supplémentaire l'exige et si vous fournissez
une route compatible.

## AdGuard Home

1. Ouvrir **Filtres > Réécritures DNS**.
2. Ajouter `upload.neostrack.com`.
3. Définir l'adresse du serveur, par exemple `192.168.1.151`.
4. Vérifier :

```bash
nslookup upload.neostrack.com 192.168.1.151
```

## Pi-hole

Ajouter un enregistrement DNS local :

```text
upload.neostrack.com 192.168.1.151
```

## DHCP

Le compteur doit recevoir l'adresse du serveur DNS local via DHCP. Une
capture typique doit montrer :

```text
NeoTrack-IP -> DNS-IP: A? upload.neostrack.com
DNS-IP -> NeoTrack-IP: A SERVER-IP
```

## Capture réseau

```bash
sudo tcpdump -i eno1 host 192.168.1.121 and port 53 -nn
sudo tcpdump -i eno1 host 192.168.1.121 and port 80 -A -s0
```

Remplacez `192.168.1.121` par l'adresse du compteur.

## Attention à Traefik

Le compteur utilise HTTP sur le port 80 et ne suit pas correctement une
redirection 301 vers HTTPS. La route `upload.neostrack.com` doit donc
rester sur l'entrypoint `web`, sans middleware de redirection HTTPS.

Si Traefik applique une redirection globale au niveau statique de
l'entrypoint `web`, une exception par label ne suffira pas. Supprimez la
redirection globale et appliquez les redirections HTTPS aux autres
routeurs individuellement.
