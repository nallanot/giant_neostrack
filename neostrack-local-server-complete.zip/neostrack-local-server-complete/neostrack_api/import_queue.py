
from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .config import settings
from .fittrackee import import_with_retry
from .storage import mark_failed, mark_processed

logger = logging.getLogger(__name__)
executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="fittrackee-import")


def process_fit(path: Path) -> None:
    try:
        import_with_retry(path)
        mark_processed(path)
    except Exception as exc:
        logger.exception("Import définitif échoué pour %s", path.name)
        mark_failed(path, str(exc))


def enqueue(path: Path) -> None:
    if not settings.import_enabled:
        logger.info("Import FitTrackee désactivé; fichier conservé: %s", path.name)
        return
    executor.submit(process_fit, path)
