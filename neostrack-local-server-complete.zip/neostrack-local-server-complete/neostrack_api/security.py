
from __future__ import annotations

from pathlib import Path
from werkzeug.utils import secure_filename


def safe_fit_filename(filename: str, fallback: str) -> str:
    clean = secure_filename(filename or "")
    if not clean:
        clean = fallback
    if not clean.lower().endswith(".fit"):
        clean += ".fit"
    return Path(clean).name
