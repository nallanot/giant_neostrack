
from __future__ import annotations

import json
import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings

logger = logging.getLogger(__name__)


def unique_path(directory: Path, filename: str) -> Path:
    candidate = directory / filename
    if not candidate.exists():
        return candidate
    stem, suffix = candidate.stem, candidate.suffix
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return directory / f"{stem}_{stamp}{suffix}"


def write_metadata(fit_path: Path, metadata: dict[str, Any]) -> Path:
    metadata_path = fit_path.with_suffix(fit_path.suffix + ".json")
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    return metadata_path


def mark_processed(path: Path) -> None:
    metadata = path.with_suffix(path.suffix + ".json")
    if settings.delete_after_import and not settings.keep_processed_copy:
        path.unlink(missing_ok=True)
        metadata.unlink(missing_ok=True)
        logger.info("Fichier local supprimé après import: %s", path.name)
        return

    destination = unique_path(settings.processed_dir, path.name)
    shutil.move(str(path), str(destination))
    if metadata.exists():
        shutil.move(str(metadata), str(destination.with_suffix(destination.suffix + ".json")))


def mark_failed(path: Path, error: str) -> None:
    metadata = path.with_suffix(path.suffix + ".json")
    destination = unique_path(settings.failed_dir, path.name)
    shutil.move(str(path), str(destination))
    if metadata.exists():
        shutil.move(str(metadata), str(destination.with_suffix(destination.suffix + ".json")))
    (destination.with_suffix(destination.suffix + ".error.txt")).write_text(error, encoding="utf-8")
