
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    data_dir: Path = Path(os.getenv("NEOSTRACK_DATA_DIR", "/data"))
    delete_after_import: bool = env_bool("DELETE_AFTER_IMPORT", True)
    keep_processed_copy: bool = env_bool("KEEP_PROCESSED_COPY", False)
    import_enabled: bool = env_bool("FITTRACKEE_IMPORT_ENABLED", False)
    fittrackee_url: str = os.getenv("FITTRACKEE_URL", "http://fittrackee:5000").rstrip("/")
    fittrackee_username: str = os.getenv("FITTRACKEE_USERNAME", "")
    fittrackee_password: str = os.getenv("FITTRACKEE_PASSWORD", "")
    request_timeout: int = int(os.getenv("REQUEST_TIMEOUT", "120"))
    import_retries: int = int(os.getenv("IMPORT_RETRIES", "5"))
    retry_delay: int = int(os.getenv("IMPORT_RETRY_DELAY", "15"))

    @property
    def incoming_dir(self) -> Path:
        return self.data_dir / "incoming"

    @property
    def processed_dir(self) -> Path:
        return self.data_dir / "processed"

    @property
    def failed_dir(self) -> Path:
        return self.data_dir / "failed"

    def ensure_directories(self) -> None:
        for directory in (self.data_dir, self.incoming_dir, self.processed_dir, self.failed_dir):
            directory.mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_directories()
