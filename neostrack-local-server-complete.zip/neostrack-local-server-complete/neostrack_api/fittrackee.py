
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

import requests

from .config import settings

logger = logging.getLogger(__name__)


class FitTrackeeImportError(RuntimeError):
    pass


def _extract_token(payload: dict[str, Any]) -> str:
    candidates = (
        payload.get("auth_token"),
        payload.get("token"),
        payload.get("access_token"),
        payload.get("data", {}).get("auth_token") if isinstance(payload.get("data"), dict) else None,
        payload.get("data", {}).get("token") if isinstance(payload.get("data"), dict) else None,
    )
    for value in candidates:
        if isinstance(value, str) and value:
            return value
    raise FitTrackeeImportError(
        "Connexion FitTrackee réussie, mais aucun jeton n'a été trouvé dans la réponse."
    )


def login() -> str:
    if not settings.fittrackee_username or not settings.fittrackee_password:
        raise FitTrackeeImportError(
            "FITTRACKEE_USERNAME et FITTRACKEE_PASSWORD doivent être configurés."
        )

    response = requests.post(
        f"{settings.fittrackee_url}/api/auth/login",
        json={
            "email": settings.fittrackee_username,
            "username": settings.fittrackee_username,
            "password": settings.fittrackee_password,
        },
        timeout=settings.request_timeout,
    )
    if response.status_code >= 400:
        raise FitTrackeeImportError(
            f"Échec de connexion FitTrackee: HTTP {response.status_code}: {response.text[:500]}"
        )
    try:
        return _extract_token(response.json())
    except ValueError as exc:
        raise FitTrackeeImportError("Réponse de connexion FitTrackee non JSON.") from exc


def upload_fit(path: Path) -> dict[str, Any]:
    token = login()
    headers = {"Authorization": f"Bearer {token}"}

    with path.open("rb") as fit_file:
        response = requests.post(
            f"{settings.fittrackee_url}/api/workouts",
            headers=headers,
            files={"file": (path.name, fit_file, "application/octet-stream")},
            timeout=settings.request_timeout,
        )

    # FitTrackee may return 201/200 or an asynchronous acceptance response.
    if response.status_code not in {200, 201, 202}:
        raise FitTrackeeImportError(
            f"Échec d'import FitTrackee: HTTP {response.status_code}: {response.text[:1000]}"
        )

    try:
        return response.json()
    except ValueError:
        return {"status_code": response.status_code, "body": response.text[:1000]}


def import_with_retry(path: Path) -> dict[str, Any]:
    last_error: Exception | None = None
    for attempt in range(1, settings.import_retries + 1):
        try:
            result = upload_fit(path)
            logger.info("Import FitTrackee réussi pour %s", path.name)
            return result
        except Exception as exc:  # Retried and persisted on final failure.
            last_error = exc
            logger.warning(
                "Import FitTrackee échoué (%s/%s) pour %s: %s",
                attempt,
                settings.import_retries,
                path.name,
                exc,
            )
            if attempt < settings.import_retries:
                time.sleep(settings.retry_delay)
    raise FitTrackeeImportError(str(last_error))
