
from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, request

from .config import settings
from .import_queue import enqueue
from .logging_config import configure_logging
from .security import safe_fit_filename
from .storage import unique_path, write_metadata

configure_logging()
logger = logging.getLogger(__name__)


def create_app() -> Flask:
    app = Flask(__name__)

    @app.get("/health")
    def health():
        return jsonify(
            {
                "status": "ok",
                "fittrackee_import_enabled": settings.import_enabled,
                "data_dir": str(settings.data_dir),
            }
        )

    @app.get("/device/bonded/<device_id>")
    def bonded(device_id: str):
        logger.info("BOND device=%s headers=%s", device_id, dict(request.headers))
        # The device proceeds when it receives HTTP 200.
        return jsonify({"result": True, "bonded": True, "device_id": device_id}), 200

    @app.get("/device/dlist/<device_id>")
    def device_list(device_id: str):
        logger.info("DLIST device=%s headers=%s", device_id, dict(request.headers))
        # An empty body was confirmed to allow the original device to continue.
        return "", 200

    @app.post("/device/upload/<device_id>")
    def upload(device_id: str):
        logger.info(
            "UPLOAD device=%s content_type=%s length=%s",
            device_id,
            request.content_type,
            request.content_length,
        )

        track = request.files.get("track")
        if track is None:
            logger.warning("Champ multipart 'track' absent.")
            return jsonify({"result": False, "error": "missing multipart field: track"}), 400

        fallback = datetime.now(timezone.utc).strftime("neostrack_%Y%m%dT%H%M%SZ.fit")
        filename = safe_fit_filename(track.filename or "", fallback)
        destination = unique_path(settings.incoming_dir, filename)
        track.save(destination)

        # Basic FIT signature check: the FIT header normally contains '.FIT'
        header = destination.read_bytes()[:32]
        if b".FIT" not in header:
            logger.warning("Le fichier %s ne contient pas la signature FIT attendue.", filename)

        metadata = {
            "device_id": device_id,
            "original_filename": track.filename,
            "saved_filename": destination.name,
            "received_at": datetime.now(timezone.utc).isoformat(),
            "remote_addr": request.remote_addr,
            "content_type": request.content_type,
            "content_length": request.content_length,
            "headers": dict(request.headers),
        }
        write_metadata(destination, metadata)
        logger.info("FIT SAVED: %s (%s octets)", destination, destination.stat().st_size)

        enqueue(destination)

        # Respond immediately so the GPS does not retry while import runs.
        return jsonify({"result": True, "saved": destination.name}), 200

    @app.route("/", defaults={"path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    @app.route("/<path:path>", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    def catch_all(path: str):
        logger.info(
            "UNKNOWN method=%s path=/%s headers=%s",
            request.method,
            path,
            dict(request.headers),
        )
        return jsonify({"result": True, "path": f"/{path}"}), 200

    return app


app = create_app()
