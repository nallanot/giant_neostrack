
#!/usr/bin/env python3
import secrets

print("APP_SECRET_KEY=" + secrets.token_urlsafe(64))
print("POSTGRES_PASSWORD=" + secrets.token_urlsafe(36))
