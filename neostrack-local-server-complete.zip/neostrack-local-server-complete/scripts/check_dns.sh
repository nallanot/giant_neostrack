
#!/bin/sh
set -eu
HOST="${1:-upload.neostrack.com}"
EXPECTED="${2:-}"
echo "Résolution DNS pour $HOST:"
getent hosts "$HOST" || true
if [ -n "$EXPECTED" ]; then
  ACTUAL="$(getent ahostsv4 "$HOST" | awk 'NR==1{print $1}')"
  [ "$ACTUAL" = "$EXPECTED" ] || {
    echo "ERREUR: obtenu '$ACTUAL', attendu '$EXPECTED'." >&2
    exit 1
  }
fi
