
#!/bin/sh
set -eu
STAMP="$(date +%Y%m%d_%H%M%S)"
DEST="${1:-./backups/$STAMP}"
mkdir -p "$DEST"
docker exec fittrackee-db pg_dump -U "${POSTGRES_USER:-fittrackee}" "${POSTGRES_DB:-fittrackee}" \
  | gzip > "$DEST/fittrackee.sql.gz"
tar -czf "$DEST/neostrack-data.tar.gz" data/incoming data/failed data/processed 2>/dev/null || true
echo "Sauvegarde créée dans $DEST"
